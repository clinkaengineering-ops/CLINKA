"use client";

import { useState } from "react";
import Link from "next/link";
import { Badge, Button, Card, StatCard } from "@/components/UI";
import { IconShield, IconWallet, IconClock } from "@/components/Icons";
import { useI18n } from "@/i18n";
import { useEngineerBalance } from "../hooks/useEngineerBalance";
import { formatMoney } from "../utils/formatMoney";
import { createEngineerWithdrawal } from "../api/payments.api";
import type { EngineerPaymentStatus } from "../types";

function statusBadgeColor(
  status: EngineerPaymentStatus,
): "green" | "amber" | "blue" | "slate" {
  switch (status) {
    case "paid":
      return "green";
    case "in_progress":
      return "blue";
    default:
      return "slate";
  }
}

export function EngineerBalancePage() {
  const { t } = useI18n();
  const { balance, loading, error, refetch } = useEngineerBalance();
  const [withdrawing, setWithdrawing] = useState(false);

  const statusLabel = (status: EngineerPaymentStatus) => {
    const key = `bal.status.${status}` as const;
    return t(key);
  };

  const handleWithdraw = async () => {
    if (balance.availableBalance <= 0) return;
    const amountStr = prompt(`Enter amount to withdraw (max ${balance.availableBalance}):`, String(balance.availableBalance));
    if (!amountStr) return;
    const amount = Number(amountStr);
    if (isNaN(amount) || amount <= 0 || amount > balance.availableBalance) {
      alert("Invalid amount.");
      return;
    }
    const method = prompt("Enter withdrawal method (e.g., Vodafone Cash, Instapay):", "Vodafone Cash");
    if (!method) return;
    const accountNumber = prompt(`Enter ${method} account number / address:`);
    if (!accountNumber) return;

    setWithdrawing(true);
    try {
      await createEngineerWithdrawal({ amount, method, accountNumber });
      alert("Withdrawal requested successfully!");
      refetch();
    } catch (err: any) {
      alert(err?.response?.data?.message ?? err.message ?? "Failed to request withdrawal");
    } finally {
      setWithdrawing(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">{t("bal.title")}</h1>
        <p className="mt-1 text-slate-500 dark:text-slate-400">
          {t("bal.subtitle")}
        </p>
      </div>

      <Card className="p-5 bg-gradient-to-br from-navy-900 to-electric-700 text-white flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <p className="text-sm text-white/70">{t("bal.available")}</p>
          <p className="text-3xl font-bold mt-1">
            {loading ? "…" : formatMoney(balance.availableBalance)}
          </p>
          <p className="text-xs text-white/60 mt-2">{t("bal.availableHint")}</p>
        </div>
        <Button 
          onClick={handleWithdraw} 
          disabled={loading || withdrawing || balance.availableBalance <= 0}
          className="bg-white text-navy-900 hover:bg-slate-100"
        >
          {withdrawing ? "Processing..." : "Withdraw Funds"}
        </Button>
      </Card>

      {error && (
        <Card className="p-4 text-sm text-rose-500 flex justify-between gap-3">
          <span>{error}</span>
          <Button size="sm" variant="ghost" onClick={() => refetch()}>
            {t("common.retry")}
          </Button>
        </Card>
      )}

      <div className="grid sm:grid-cols-3 gap-4 text-sm">
        <StatCard
          label="Pending Balance"
          value={loading ? "…" : formatMoney(balance.pendingBalance)}
          icon={<IconClock width={20} height={20} className="text-purple-500" />}
        />
        <StatCard
          label={t("bal.secured")}
          value={loading ? "…" : formatMoney(balance.securedBalance)}
          icon={<IconShield width={20} height={20} className="text-blue-500" />}
        />
        <StatCard
          label={t("bal.awaitingClient")}
          value={loading ? "…" : formatMoney(balance.awaitingClientPayment)}
          icon={<IconWallet width={20} height={20} className="text-slate-500" />}
        />
      </div>

      <Card className="p-5">
        <h2 className="font-bold text-sm">{t("bal.howTitle")}</h2>
        <ol className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-400 list-decimal list-inside">
          <li>{t("bal.how1")}</li>
          <li>{t("bal.how2")}</li>
          <li>{t("bal.how3")}</li>
          <li>{t("bal.how4")}</li>
        </ol>
      </Card>

      {!loading && balance.withdrawalRequests && balance.withdrawalRequests.length > 0 && (
        <Card className="divide-y divide-slate-100 dark:divide-slate-800">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800">
            <h2 className="font-bold">Withdrawal History</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-500 text-xs uppercase">
                  <th className="text-start p-3 font-semibold">Date</th>
                  <th className="text-start p-3 font-semibold">Amount</th>
                  <th className="text-start p-3 font-semibold">Method</th>
                  <th className="text-start p-3 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {balance.withdrawalRequests.map((req) => (
                  <tr key={req.id} className="border-b border-slate-50 dark:border-slate-800/50">
                    <td className="p-3 text-slate-600 dark:text-slate-400">
                      {new Date(req.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-3 font-semibold text-emerald-600 dark:text-emerald-400">
                      {formatMoney(req.amount)}
                    </td>
                    <td className="p-3">
                      <p>{req.method}</p>
                      <p className="text-xs text-slate-500">{req.accountNumber}</p>
                    </td>
                    <td className="p-3">
                      <Badge color={req.status === "COMPLETED" ? "green" : req.status === "REJECTED" ? "rose" : req.status === "PROCESSING" ? "blue" : "amber"}>
                        {req.status}
                      </Badge>
                      {req.adminNotes && <p className="text-xs mt-1 text-slate-500">Note: {req.adminNotes}</p>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {loading ? (
        <Card className="p-12 text-center text-slate-500">
          {t("common.loading")}
        </Card>
      ) : balance.transactions.length === 0 ? (
        <Card className="p-8 text-center text-slate-500">
          <p>{t("bal.empty")}</p>
          <Link href="/projects" className="inline-block mt-4">
            <Button variant="secondary">{t("side.findProjects")}</Button>
          </Link>
        </Card>
      ) : (
        <Card className="divide-y divide-slate-100 dark:divide-slate-800">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800">
            <h2 className="font-bold">{t("bal.transactions")}</h2>
          </div>
          {balance.transactions.map((tx) => (
            <div
              key={tx.id}
              className="p-4 flex flex-wrap items-center justify-between gap-3"
            >
              <div>
                <p className="font-semibold">{tx.projectTitle}</p>
                <p className="text-sm text-slate-500 mt-0.5">
                  {formatMoney(tx.netAmount)}{" "}
                  <span className="text-xs">
                    ({t("bal.netAfterFee")})
                  </span>
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge color={statusBadgeColor(tx.status)}>
                  {statusLabel(tx.status)}
                </Badge>
                <Link href={`/messages?project=${tx.projectId}`}>
                  <Button size="sm" variant="secondary">
                    {t("bal.openChat")}
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}
