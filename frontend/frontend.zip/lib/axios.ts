// lib/axios.ts
// Single axios instance used by every API module.
import axios from "axios";

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api",
  withCredentials: true,
});

const PUBLIC_PATH_PREFIXES = ["/login", "/register", "/verify", "/forgot-password", "/reset-password"];

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (
      typeof window !== "undefined" &&
      error.response?.status === 401
    ) {
      const path = window.location.pathname;
      const isPublic = PUBLIC_PATH_PREFIXES.some(
        (p) => path === p || path.startsWith(`${p}/`),
      );
      if (!isPublic) {
        const next = encodeURIComponent(path);
        window.location.href = `/login?next=${next}`;
      }
    }
    return Promise.reject(error);
  },
);

export default api;
