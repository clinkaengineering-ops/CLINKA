"use client";
import { useState } from "react";
import Link from "next/link";
import { useRegister } from "@/features/auth/hooks/useRegister";
import { startGoogleSignIn } from "@/features/auth/lib/googleAuth";
import {
  clientRegisterFormSchema,
  engineerRegisterStep2Schema,
  engineerRegisterStep3Schema,
  engineerRegisterStep4Schema,
  validateForm,
  type FieldErrors,
} from "@/lib/validation";
import { cn } from "@/utils/cn";
import { Button, Card, Divider, Field, Input, Textarea } from "@/components/UI";
import {
  IconArrow,
  IconBriefcase,
  IconCheck,
  IconLock,
  IconMail,
  IconUser,
} from "@/components/Icons";
import { useI18n } from "@/i18n";

type Role = "CLIENT" | "ENGINEER";
type Specialty = "CIVIL" | "ARCHITECTURAL";
type DocumentType = "collegeIdUrl" | "certificateUrl" | "syndicateCardUrl";

export function RegisterForm() {
  const { t } = useI18n();
  const { registerClient, registerEngineer, loading, error } = useRegister();
  const [step, setStep] = useState(1);
  const [role, setRole] = useState<Role | null>(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    specialty: "" as Specialty,
    bio: "",
    nationality: "",
    documentType: "" as DocumentType,
    file: null as File | null,
  });
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});

  const stepLabels = [t("auth.s1"), t("auth.s2details"), t("auth.s3"), t("auth.s4")];

  const documentOptions = [
    { type: "collegeIdUrl" as DocumentType, label: t("auth.doc.collegeId") },
    { type: "certificateUrl" as DocumentType, label: t("auth.doc.certificate") },
    { type: "syndicateCardUrl" as DocumentType, label: t("auth.doc.syndicate") },
  ];

  function validateCurrentStep(): boolean {
    if (step === 1) {
      if (!role) {
        setFieldErrors({
          _form: t("auth.selectRole"),
        });
        return false;
      }
      setFieldErrors({});
      return true;
    }
    if (step === 2) {
      const result = validateForm(engineerRegisterStep2Schema, form);
      if (!result.success) {
        setFieldErrors(result.errors);
        return false;
      }
      setFieldErrors({});
      return true;
    }
    if (step === 3 && role === "ENGINEER") {
      const result = validateForm(engineerRegisterStep3Schema, {
        specialty: form.specialty || undefined,
        bio: form.bio || undefined,
        nationality: form.nationality || undefined,
      });
      if (!result.success) {
        setFieldErrors(result.errors);
        return false;
      }
      setFieldErrors({});
      return true;
    }
    if (step === 4 && role === "ENGINEER") {
      const result = validateForm(engineerRegisterStep4Schema, {
        documentType: form.documentType || undefined,
        file: form.file ?? undefined,
      });
      if (!result.success) {
        setFieldErrors(result.errors);
        return false;
      }
      setFieldErrors({});
      return true;
    }
    return true;
  }

  function goNext() {
    if (!validateCurrentStep()) return;
    setStep(step + 1);
  }

  async function handleDone() {
    if (!validateCurrentStep()) return;
    if (role === "CLIENT") {
      const result = validateForm(clientRegisterFormSchema, form);
      if (!result.success) {
        setFieldErrors(result.errors);
        return;
      }
    }
    if (role === "CLIENT") {
      await registerClient({
        name: form.name,
        email: form.email,
        password: form.password,
      });
    } else {
      await registerEngineer({
        name: form.name,
        email: form.email,
        password: form.password,
        specialty: form.specialty,
        bio: form.bio,
        nationality: form.nationality,
        documentType: form.documentType,
        file: form.file!,
      });
    }
  }

  return (
    <Card className="p-6 sm:p-8">
      <p className="text-xs uppercase tracking-wider text-electric-600 font-bold">
        {t("auth.step")} {step} {t("auth.of")} {role === "CLIENT" ? 2 : stepLabels.length}
      </p>
      <h1 className="mt-1 text-2xl font-bold">{stepLabels[step - 1]}</h1>

      {/* Progress bar */}
      <div className="mt-3 flex gap-2">
        {(role === "CLIENT" ? [1, 2] : [1, 2, 3, 4]).map((_, i) => (
          <div
            key={i}
            className={cn(
              "h-1 flex-1 rounded-full transition",
              i + 1 <= step
                ? "bg-electric-500"
                : "bg-slate-200 dark:bg-slate-800",
            )}
          />
        ))}
      </div>

      {error && <p className="text-rose-500 text-sm mt-3">{error}</p>}
      {fieldErrors._form && (
        <p className="text-rose-500 text-sm mt-3">{fieldErrors._form}</p>
      )}

      <div className="mt-6">
        {/* Step 1 — Role selection */}
        {step === 1 && (
          <div className="space-y-3">
            {[
              {
                role: "ENGINEER" as Role,
                title: t("auth.iEngShort"),
                desc: t("auth.iEngShortDesc"),
                icon: <IconBriefcase width={20} height={20} />,
              },
              {
                role: "CLIENT" as Role,
                title: t("auth.iClientShort"),
                desc: t("auth.iClientShortDesc"),
                icon: <IconUser width={20} height={20} />,
              },
            ].map((o) => (
              <button
                key={o.role}
                onClick={() => setRole(o.role)}
                className={cn(
                  "w-full p-4 rounded-xl border text-start transition flex items-center gap-3 group",
                  role === o.role
                    ? "border-electric-500 bg-electric-500/5"
                    : "border-slate-200 dark:border-slate-800 hover:border-electric-500/60 hover:bg-electric-500/5",
                )}
              >
                <span className="h-10 w-10 rounded-lg bg-electric-500/10 text-electric-600 flex items-center justify-center group-hover:scale-110 transition">
                  {o.icon}
                </span>
                <div className="flex-1">
                  <p className="font-semibold">{o.title}</p>
                  <p className="text-xs text-slate-500">{o.desc}</p>
                </div>
                {role === o.role ? (
                  <IconCheck
                    width={18}
                    height={18}
                    className="text-electric-500"
                  />
                ) : (
                  <IconArrow
                    width={16}
                    height={16}
                    className="text-slate-400 rtl:rotate-180"
                  />
                )}
              </button>
            ))}
          </div>
        )}

        {/* Step 2 — Basic details */}
        {step === 2 && (
          <div className="space-y-4">
            {role && (
              <>
                <Button
                  type="button"
                  variant="secondary"
                  className="w-full !h-11"
                  onClick={() => startGoogleSignIn({ role: role ?? "CLIENT" })}
                >
                  {t("auth.google")}
                </Button>
                <Divider label={t("common.or")} />
              </>
            )}
            <Field label={t("auth.fullName")} error={fieldErrors.name}>
              <Input
                icon={<IconUser width={16} height={16} />}
                type="text"
                placeholder={t("auth.namePh")}
                value={form.name}
                error={!!fieldErrors.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </Field>
            <Field label={t("auth.email")} error={fieldErrors.email}>
              <Input
                icon={<IconMail width={16} height={16} />}
                type="email"
                placeholder={t("auth.emailPh")}
                value={form.email}
                error={!!fieldErrors.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </Field>
            <Field label={t("auth.password")} error={fieldErrors.password}>
              <Input
                icon={<IconLock width={16} height={16} />}
                type="password"
                placeholder={t("auth.passMin")}
                value={form.password}
                error={!!fieldErrors.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </Field>
          </div>
        )}

        {/* Step 3 — Specialty + Bio + Nationality (Engineer only) */}
        {step === 3 && role === "ENGINEER" && (
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {t("auth.specialty")}
              </label>
              {fieldErrors.specialty && (
                <p className="mt-1 text-xs text-rose-500">
                  {fieldErrors.specialty}
                </p>
              )}

              <div className="mt-1.5 grid grid-cols-2 gap-3">
                {(["CIVIL", "ARCHITECTURAL"] as Specialty[]).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setForm({ ...form, specialty: s })}
                    className={cn(
                      "p-3 rounded-xl border text-sm font-semibold text-center transition",
                      form.specialty === s
                        ? "border-electric-500 bg-electric-500/5 text-electric-600"
                        : "border-slate-200 dark:border-slate-800 hover:border-electric-500/60",
                    )}
                  >
                    {s === "CIVIL" ? t("auth.civil") : t("auth.architectural")}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {t("auth.bio")}{" "}
                <span className="text-slate-400 font-normal">({t("auth.optional")})</span>
              </label>

              <Textarea
                rows={3}
                placeholder={t("auth.bioPh")}
                value={form.bio}
                onChange={(e: any) => setForm({ ...form, bio: e.target.value })}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {t("em.nationality")}
              </label>
              {fieldErrors.nationality && (
                <p className="mt-1 text-xs text-rose-500">
                  {fieldErrors.nationality}
                </p>
              )}

              <select
                value={form.nationality}
                onChange={(e) =>
                  setForm({ ...form, nationality: e.target.value })
                }
                className="mt-1.5 w-full h-11 px-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-electric-500/30"
              >
                <option value="">{t("auth.nationalityPh")}</option>

                {[
                  "Afghan",
                  "Albanian",
                  "Algerian",
                  "Argentine",
                  "Armenian",
                  "Australian",
                  "Austrian",
                  "Azerbaijani",
                  "Bangladeshi",
                  "Belarusian",
                  "Belgian",
                  "Bolivian",
                  "Bosnian",
                  "Brazilian",
                  "British",
                  "Bulgarian",
                  "Cambodian",
                  "Cameroonian",
                  "Canadian",
                  "Chilean",
                  "Chinese",
                  "Colombian",
                  "Congolese",
                  "Croatian",
                  "Cuban",
                  "Czech",
                  "Danish",
                  "Dutch",
                  "Ecuadorian",
                  "Egyptian",
                  "Emirati",
                  "English",
                  "Estonian",
                  "Ethiopian",
                  "Finnish",
                  "French",
                  "Georgian",
                  "German",
                  "Ghanaian",
                  "Greek",
                  "Guatemalan",
                  "Hungarian",
                  "Indian",
                  "Indonesian",
                  "Iranian",
                  "Iraqi",
                  "Irish",
                  "Israeli",
                  "Italian",
                  "Jamaican",
                  "Japanese",
                  "Jordanian",
                  "Kazakh",
                  "Kenyan",
                  "Kuwaiti",
                  "Lebanese",
                  "Libyan",
                  "Lithuanian",
                  "Malaysian",
                  "Mexican",
                  "Mongolian",
                  "Moroccan",
                  "Nepalese",
                  "New Zealander",
                  "Nigerian",
                  "Norwegian",
                  "Omani",
                  "Pakistani",
                  "Palestinian",
                  "Peruvian",
                  "Philippine",
                  "Polish",
                  "Portuguese",
                  "Qatari",
                  "Romanian",
                  "Russian",
                  "Saudi",
                  "Scottish",
                  "Serbian",
                  "Singaporean",
                  "Slovak",
                  "Slovenian",
                  "Somali",
                  "South African",
                  "South Korean",
                  "Spanish",
                  "Sri Lankan",
                  "Sudanese",
                  "Swedish",
                  "Swiss",
                  "Syrian",
                  "Taiwanese",
                  "Tanzanian",
                  "Thai",
                  "Tunisian",
                  "Turkish",
                  "Ukrainian",
                  "Uruguayan",
                  "American",
                  "Uzbek",
                  "Venezuelan",
                  "Vietnamese",
                  "Yemeni",
                  "Zimbabwean",
                  "Other",
                ].map((nationality) => (
                  <option key={nationality} value={nationality}>
                    {nationality}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* Step 4 — Document upload (Engineer only) */}
        {step === 4 && role === "ENGINEER" && (
          <div className="space-y-4">
            <p className="text-sm text-slate-500">{t("auth.uploadDocHint")}</p>
            {(fieldErrors.documentType || fieldErrors.file) && (
              <p className="text-xs text-rose-500">
                {fieldErrors.documentType ?? fieldErrors.file}
              </p>
            )}
            <div className="space-y-3">
              {documentOptions.map((d) => (
                <label
                  key={d.type}
                  className={cn(
                    "flex items-center justify-between p-3 rounded-xl border border-dashed cursor-pointer transition",
                    form.documentType === d.type
                      ? "border-electric-500 bg-electric-500/5"
                      : "border-slate-300 dark:border-slate-700 hover:border-electric-500",
                  )}
                >
                  <span className="text-sm font-medium">{d.label}</span>
                  <input
                    type="file"
                    accept=".jpg,.jpeg,.png,.pdf"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files?.[0]) {
                        setForm({
                          ...form,
                          documentType: d.type,
                          file: e.target.files[0],
                        });
                      }
                    }}
                  />
                  <span className="text-xs text-electric-600 font-semibold">
                    {form.documentType === d.type && form.file
                      ? form.file.name
                      : t("auth.upload")}
                  </span>
                </label>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Navigation buttons */}
      <div className="mt-6 flex justify-between gap-3">
        <button
          onClick={() => setStep(Math.max(1, step - 1))}
          disabled={step === 1}
          className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-slate-900 disabled:opacity-30"
        >
          {t("auth.back")}
        </button>

        {step < (role === "CLIENT" ? 2 : 4) ? (
          <Button onClick={goNext} icon={<IconArrow width={14} height={14} />}>
            {t("auth.continue")}
          </Button>
        ) : (
          <Button
            onClick={handleDone}
            disabled={loading}
            icon={<IconCheck width={14} height={14} />}
          >
            {loading ? t("auth.creating") : t("auth.finishBtn")}
          </Button>
        )}
      </div>

      <p className="text-center text-sm text-slate-500 mt-4">
        {t("auth.have")}{" "}
        <Link
          href="/login"
          className="text-electric-600 font-semibold hover:underline"
        >
          {t("auth.signInLink")}
        </Link>
      </p>
    </Card>
  );
}
