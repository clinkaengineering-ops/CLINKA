"use client";

import Link from "next/link";
import { Badge, Button, Card, StatCard } from "@/components/UI";
import {
  IconUsers,
  IconWallet,
  IconShield,
  IconAlert,
  IconCheck,
  IconClose,
} from "@/components/Icons";
import { useI18n } from "@/i18n";
import useAuthStore from "@/store/authStore";
import { useAdmin } from "../hooks/useAdmin";

function formatMoney(n: number) {
  return new Intl.NumberFormat("en-EG", {
    style: "currency",
    currency: "EGP",
    maximumFractionDigits: 0,
  }).format(n);
}

export function AdminPage() {
  const { t } = useI18n();
  const user = useAuthStore((s) => s.user);
  const {
    stats,
    verifications,
    loading,
    error,
    actionLoading,
    refetch,
    approve,
    reject,
  } = useAdmin();

  if (user?.role !== "ADMIN") {
    return (
      <div className="max-w-7xl mx-auto py-20 text-center">
        <p className="text-slate-500">{t("ad.accessDenied")}</p>
        <Link href="/dashboard" className="inline-block mt-4">
          <Button variant="secondary">{t("side.clientDash")}</Button>
        </Link>
      </div>
    );
  }

  function handleExport() {
    const rows = [
      ["Name", "Email", "Specialty", "Document", "Submitted"],
      ...verifications.map((v) => [
        v.name,
        v.email,
        v.specialty,
        v.documentType,
        new Date(v.submittedAt).toISOString(),
      ]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "pending-verifications.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <p className="text-sm text-slate-500 flex items-center gap-2">
            <IconShield width={14} height={14} className="text-electric-500" />
            Admin Console
          </p>
          <h1 className="text-3xl font-bold tracking-tight">{t("ad.title")}</h1>
        </div>
        <Button variant="secondary" onClick={handleExport} disabled={loading}>
          {t("common.exportCsv")}
        </Button>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-600 flex justify-between items-center">
          <span>{error}</span>
          <Button size="sm" variant="ghost" onClick={() => refetch()}>
            {t("common.retry")}
          </Button>
        </div>
      )}

      {loading ? (
        <Card className="p-12 text-center text-slate-500">{t("common.loading")}</Card>
      ) : stats ? (
        <>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              label={t("ad.totalUsers")}
              value={stats.totalUsers.toLocaleString()}
              icon={<IconUsers width={20} height={20} />}
            />
            <StatCard
              label={t("ad.gmv")}
              value={formatMoney(stats.gmv)}
              icon={<IconWallet width={20} height={20} />}
            />
            <StatCard
              label={t("ad.verifPending")}
              value={String(stats.pendingVerifications)}
              icon={<IconShield width={20} height={20} />}
            />
            <StatCard
              label={t("ad.disputesOpen")}
              value={String(stats.openDisputes)}
              icon={<IconAlert width={20} height={20} />}
            />
          </div>

          <Card>
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <h2 className="font-bold">{t("ad.pendingVerifications")}</h2>
              <Badge color="amber">
                {verifications.length} {t("ad.pending")}
              </Badge>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {verifications.length === 0 ? (
                <p className="p-8 text-center text-sm text-slate-500">
                  {t("ad.noPending")}
                </p>
              ) : (
                verifications.map((v) => (
                  <div
                    key={v.profileId}
                    className="p-4 flex items-center justify-between gap-4 flex-wrap"
                  >
                    <div>
                      <p className="font-semibold text-sm">{v.name}</p>
                      <p className="text-xs text-slate-500">
                        {v.email} · {v.specialty} · {v.documentType}
                      </p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {v.collegeIdUrl && (
                          <a
                            href={v.collegeIdUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-xs text-electric-600 hover:underline"
                          >
                            College ID
                          </a>
                        )}
                        {v.certificateUrl && (
                          <a
                            href={v.certificateUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-xs text-electric-600 hover:underline"
                          >
                            Certificate
                          </a>
                        )}
                        {v.syndicateCardUrl && (
                          <a
                            href={v.syndicateCardUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-xs text-electric-600 hover:underline"
                          >
                            Syndicate
                          </a>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        icon={<IconCheck width={14} height={14} />}
                        disabled={actionLoading === v.profileId}
                        onClick={() => approve(v.profileId)}
                      >
                        {t("ad.approve")}
                      </Button>
                      <Button
                        size="sm"
                        variant="danger"
                        icon={<IconClose width={14} height={14} />}
                        disabled={actionLoading === v.profileId}
                        onClick={() => reject(v.profileId)}
                      >
                        {t("ad.reject")}
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>
        </>
      ) : null}
    </div>
  );
}
