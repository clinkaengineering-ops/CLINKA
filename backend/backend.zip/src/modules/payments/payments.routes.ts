import { Router } from "express";
import {
  authenticate,
  authorize,
} from "../../middlewares/auth.middleware";
import {
  fawaterkWebhookController,
  getEscrowByIdController,
  getPaymentMethodsController,
  getProjectPaymentController,
  initiateCheckoutController,
  listEngineerEscrowController,
  listEscrowController,
  refundEscrowController,
  releaseEscrowController,
} from "./payments.controller";

const router = Router();

router.post("/webhook_json", fawaterkWebhookController);

router.get("/methods", authenticate, getPaymentMethodsController);
router.get("/escrow", authenticate, authorize("CLIENT"), listEscrowController);
router.get(
  "/engineer/escrow",
  authenticate,
  authorize("ENGINEER"),
  listEngineerEscrowController,
);
router.get(
  "/escrow/:paymentId",
  authenticate,
  getEscrowByIdController,
);
router.get(
  "/projects/:projectId",
  authenticate,
  getProjectPaymentController,
);
router.post(
  "/projects/:projectId/checkout",
  authenticate,
  authorize("CLIENT"),
  initiateCheckoutController,
);
router.post(
  "/:paymentId/release",
  authenticate,
  authorize("CLIENT"),
  releaseEscrowController,
);
router.post(
  "/:paymentId/refund",
  authenticate,
  authorize("CLIENT"),
  refundEscrowController,
);

export default router;
