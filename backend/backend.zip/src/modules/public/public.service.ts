import db from "../../config/db";

function formatCompactCurrency(amount: number): string {
  if (amount >= 1_000_000) return `$${(amount / 1_000_000).toFixed(1)}M`;
  if (amount >= 1_000) return `$${Math.round(amount / 1_000)}K`;
  return `$${Math.round(amount)}`;
}

export async function getLandingSnapshot() {
  const [
    totalProjects,
    openProjects,
    completedProjects,
    totalBids,
    verifiedEngineers,
    releasedPayments,
    engineers,
    recentReviews,
  ] = await Promise.all([
    db.project.count(),
    db.project.count({ where: { status: "OPEN" } }),
    db.project.count({ where: { status: "COMPLETED" } }),
    db.bid.count(),
    db.engineerProfile.count({ where: { verificationStatus: "APPROVED" } }),
    db.payment.findMany({
      where: { status: "RELEASED" },
      select: { amount: true },
    }),
    db.user.findMany({
      where: {
        role: "ENGINEER",
        profile: { verificationStatus: "APPROVED" },
      },
      take: 8,
      include: {
        profile: {
          include: {
            reviews: { select: { rating: true } },
            portfolio: { take: 3, select: { description: true } },
          },
        },
      },
      orderBy: { createdAt: "desc" },
    }),
    db.review.findMany({
      where: { comment: { not: null } },
      take: 6,
      orderBy: { createdAt: "desc" },
      include: {
        client: { select: { name: true } },
        engineer: {
          include: {
            user: { select: { name: true } },
          },
        },
      },
    }),
  ]);

  const escrowReleasedTotal = releasedPayments.reduce((s, p) => s + p.amount, 0);

  const featuredEngineers = engineers
    .map((e) => {
      const ratings = e.profile?.reviews ?? [];
      const avg =
        ratings.length > 0
          ? ratings.reduce((s, r) => s + r.rating, 0) / ratings.length
          : 0;
      return {
        id: e.id,
        name: e.name,
        specialty: e.profile?.specialty ?? "ENGINEERING",
        rating: Math.round(avg * 10) / 10,
        projectCount: ratings.length,
        skills: (e.profile?.portfolio ?? [])
          .map((p) => p.description)
          .filter(Boolean)
          .slice(0, 3),
      };
    })
    .sort((a, b) => b.rating - a.rating || b.projectCount - a.projectCount)
    .slice(0, 4);

  const testimonials = recentReviews
    .filter((r) => r.comment?.trim())
    .slice(0, 3)
    .map((r) => ({
      quote: r.comment!.trim(),
      name: r.client.name,
      role: r.engineer.user.name,
      rating: r.rating,
    }));

  return {
    stats: {
      totalProjects,
      openProjects,
      completedProjects,
      totalBids,
      verifiedEngineers,
      escrowReleasedTotal,
      escrowReleasedLabel: formatCompactCurrency(escrowReleasedTotal),
      avgBidsPerOpenProject:
        openProjects > 0 ? Math.round(totalBids / openProjects) : totalBids,
    },
    featuredEngineers,
    testimonials,
  };
}
