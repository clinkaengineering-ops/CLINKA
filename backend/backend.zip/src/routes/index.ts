import { Application } from "express"
import authRouter from "../modules/auth/auth.routes"
import userRouter from "../modules/users/user.routes"

export default function registerRoutes(app: Application) {
  app.use("/api/auth", authRouter)
  app.use("/api/users", userRouter)
} 