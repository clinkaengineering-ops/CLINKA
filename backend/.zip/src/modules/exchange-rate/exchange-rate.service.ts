import db from "../../config/db";
import ApiError from "../../utils/ApiError";
import type { ExchangeRateProvider, CurrencyConverter, ExchangeRateResult } from "./exchange-rate.interface";

/**
 * Hardcoded fallback rates — used ONLY when both the exchange rate API and the
 * database cache are unavailable.  This prevents checkout from being completely
 * blocked when the external API is down.  The rate should be updated periodically
 * to stay roughly accurate.
 */
const FALLBACK_RATES: Record<string, number> = {
  // Using || instead of ?? so that empty strings (common in Coolify env vars) 
  // correctly fall back to "50.50" instead of evaluating to 0.
  USD_EGP: Number(process.env.FALLBACK_USD_EGP_RATE || "50.50"),
};

function getFallbackRate(base: string, target: string): ExchangeRateResult | null {
  const key = `${base}_${target}`;
  const rate = FALLBACK_RATES[key];
  if (!rate || rate <= 0) return null;
  return {
    rate,
    provider: "hardcoded-fallback",
    timestamp: new Date(),
  };
}

export class ExchangeRateService implements CurrencyConverter {
  constructor(private readonly provider: ExchangeRateProvider) {}

  /**
   * Refreshes the rate in the cache by fetching from the provider.
   * If it fails or returns an invalid rate, it keeps the old cache and logs an error.
   */
  async refreshRate(base: string, target: string): Promise<void> {
    try {
      const result = await this.provider.getExchangeRate(base, target);
      if (result.rate <= 0) {
        throw new ApiError(502, `Invalid exchange rate received from provider: ${result.rate}`);
      }

      await db.exchangeRateCache.upsert({
        where: { base_target: { base, target } },
        update: {
          rate: result.rate,
          provider: result.provider,
          fetchedAt: result.timestamp,
        },
        create: {
          id: `${base}_${target}`,
          base,
          target,
          rate: result.rate,
          provider: result.provider,
          fetchedAt: result.timestamp,
        },
      });

      console.info(`[ExchangeRateService] Refreshed rate ${base}->${target}: ${result.rate}`);
    } catch (err: any) {
      console.error(`[ExchangeRateService] Failed to refresh rate ${base}->${target}: ${err.message}`);
      // Do not crash, keep the old cache
    }
  }

  /**
   * Retrieves the latest rate. Tries to fetch live; falls back to cache;
   * last resort: hardcoded fallback.
   */
  async getExchangeRate(base: string, target: string): Promise<ExchangeRateResult> {
    const cached = await db.exchangeRateCache.findUnique({
      where: { base_target: { base, target } },
    });

    if (!cached) {
      console.warn(`[ExchangeRateService] Cache miss for ${base}->${target}. Attempting synchronous fetch...`);
      // If there is no cache at all, we MUST fetch it synchronously or fail.
      await this.refreshRate(base, target);
      const newlyCached = await db.exchangeRateCache.findUnique({
        where: { base_target: { base, target } },
      });

      if (newlyCached) {
        return {
          rate: Number(newlyCached.rate),
          provider: newlyCached.provider,
          timestamp: newlyCached.fetchedAt,
        };
      }

      // Last resort — use hardcoded fallback so checkout is not blocked
      const fallback = getFallbackRate(base, target);
      if (fallback) {
        console.warn(
          `[ExchangeRateService] WARNING: Using hardcoded fallback rate ${base}->${target}: ${fallback.rate}. ` +
          `Exchange rate API and DB cache are both unavailable.`,
        );
        return fallback;
      }

      throw new ApiError(503, `Exchange rate not available for ${base}->${target}. Please try again later.`);
    }

    return {
      rate: Number(cached.rate),
      provider: cached.provider,
      timestamp: cached.fetchedAt,
    };
  }

  /**
   * Warms up the cache on server start.
   */
  async warmCache(base: string, target: string): Promise<void> {
    console.info(`[ExchangeRateService] Warming cache for ${base}->${target}...`);
    await this.refreshRate(base, target);
    
    const count = await db.exchangeRateCache.count({
      where: { base, target },
    });

    if (count === 0) {
      console.error(`[ExchangeRateService] CRITICAL: Failed to warm cache for ${base}->${target}. Payments may fail.`);
    } else {
      console.info(`[ExchangeRateService] Cache warmed successfully for ${base}->${target}.`);
    }
  }

  /**
   * CurrencyConverter implementation enforcing a single rounding rule globally.
   */
  async convert(amountUsd: number, from: string, to: string): Promise<{ amountConverted: number; rateUsed: ExchangeRateResult }> {
    if (from === to) {
      return {
        amountConverted: amountUsd,
        rateUsed: { rate: 1, provider: "internal", timestamp: new Date() },
      };
    }

    const rateResult = await this.getExchangeRate(from, to);
    
    // Global rounding rule: round to 2 decimal places.
    const amountConverted = Math.round(amountUsd * rateResult.rate * 100) / 100;
    
    return {
      amountConverted,
      rateUsed: rateResult,
    };
  }
}
