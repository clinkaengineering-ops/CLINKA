import db from "../../config/db";
import { getFawaterkConfig } from "../../config/fawaterk";
import {
  DEV_PAYMENT_METHODS,
  useFawaterkDevFallback,
} from "../../config/fawaterk.dev";
import ApiError from "../../utils/ApiError";
import {
  getFawaterkPaymentMethods,
  initiateFawaterkPayment,
} from "./fawaterk.api";
import {
  verifyExpiredWebhookHash,
  verifyPaidWebhookHash,
} from "./fawaterk.webhook";
import { buildIframeHashKey } from "./fawaterk.hashkey";
import {
  CreateWithdrawalRequestInput,
  expiredWebhookSchema,
  InitiateCheckoutInput,
  paidWebhookSchema,
} from "./payments.validation";
import {
  netEngineerAmount,
  recordPaymentLedger,
} from "../../utils/paymentLedger";
import { isReviewableStatus } from "../projects/project.status";
import transporter from "../../config/mailer";
import {
  ensureWallet,
  settleMaturedWalletTransactions,
  walletHoldReleaseDate,
} from "../../utils/wallet";

function parsePayLoad(
  raw: unknown,
): { projectId?: number; paymentId?: number } | null {
  if (raw == null) return null;
  let obj: unknown = raw;
  if (typeof raw === "string") {
    try {
      obj = JSON.parse(raw);
    } catch {
      return null;
    }
  }
  if (typeof obj !== "object" || obj === null) return null;
  const o = obj as Record<string, unknown>;
  return {
    projectId: o.projectId != null ? Number(o.projectId) : undefined,
    paymentId: o.paymentId != null ? Number(o.paymentId) : undefined,
  };
}

let fawaterkFallbackLogged = false;

function toNumber(value: number | { toString(): string }) {
  return typeof value === "number" ? value : Number(value.toString());
}

function logFawaterkFallbackOnce(message: string) {
  if (fawaterkFallbackLogged) return;
  fawaterkFallbackLogged = true;
  console.warn(
    `[payments] ${message} — using dev payment methods (Visa, Fawry, Meeza). ` +
    "Enable payment methods in your Fawaterak dashboard or contact Fawaterak support if the list stays empty.",
  );
}

function splitCustomerName(fullName: string): {
  first_name: string;
  last_name: string;
} {
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 1) {
    return { first_name: parts[0], last_name: parts[0] };
  }
  return {
    first_name: parts[0],
    last_name: parts.slice(1).join(" "),
  };
}

function getRedirectionUrls(projectId: number, paymentId: number) {
  const clientUrl = (process.env.CLIENT_URL ?? "http://localhost:3000").replace(
    /\/$/,
    "",
  );
  const apiUrl = (
    process.env.API_URL ?? `http://localhost:${process.env.PORT ?? 5000}`
  ).replace(/\/$/, "");

  return {
    successUrl: `${clientUrl}/checkout?projectId=${projectId}&paymentId=${paymentId}&status=success`,
    failUrl: `${clientUrl}/checkout?projectId=${projectId}&paymentId=${paymentId}&status=fail`,
    pendingUrl: `${clientUrl}/checkout?projectId=${projectId}&paymentId=${paymentId}&status=pending`,
    webhookUrl: `${apiUrl}/api/payments/webhook_json`,
  };
}

function formatEgp(amount: number) {
  return `${Math.round(amount * 100) / 100} EGP`;
}

async function sendWithdrawalRequestEmailToAdmins(input: {
  engineerName: string;
  engineerEmail: string;
  amount: number;
  method: string;
  accountNumber: string;
  requestDate: Date;
}) {
  const admins = await db.user.findMany({
    where: { role: "ADMIN" },
    select: { email: true },
  });
  const recipients = admins
    .map((a) => a.email?.trim())
    .filter((email): email is string => Boolean(email));

  if (recipients.length === 0) return;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: recipients.join(","),
      subject: `New Withdrawal Request - ${formatEgp(input.amount)}`,
      html: `
        <h3>New Withdrawal Request</h3>
        <p><strong>Engineer Name:</strong> ${input.engineerName}</p>
        <p><strong>Engineer Email:</strong> ${input.engineerEmail}</p>
        <p><strong>Withdrawal Amount:</strong> ${formatEgp(input.amount)}</p>
        <p><strong>Withdrawal Method:</strong> ${input.method}</p>
        <p><strong>Account Number:</strong> ${input.accountNumber}</p>
        <p><strong>Request Date:</strong> ${input.requestDate.toISOString()}</p>
      `,
    });
  } catch (error) {
    console.warn(
      "Failed to send withdrawal notification email:",
      error instanceof Error ? error.message : "Unknown error",
    );
  }
}

async function getAcceptedBidForProject(projectId: number) {
  const bid = await db.bid.findFirst({
    where: { projectId, status: "ACCEPTED" },
    include: {
      engineer: { include: { user: { select: { id: true } } } },
    },
  });
  if (!bid) {
    throw new ApiError(400, "No accepted bid found for this project");
  }
  return bid;
}

export async function listPaymentMethods() {
  if (!process.env.FAWATERK_API_TOKEN?.trim()) {
    if (useFawaterkDevFallback()) {
      logFawaterkFallbackOnce("FAWATERK_API_TOKEN missing");
      return DEV_PAYMENT_METHODS;
    }
    throw new ApiError(
      503,
      "Payment gateway is not configured (FAWATERK_API_TOKEN)",
    );
  }

  try {
    const methods = await getFawaterkPaymentMethods();
    if (methods.length > 0) return methods;
    if (useFawaterkDevFallback()) {
      logFawaterkFallbackOnce(
        "Fawaterk API returned success but zero payment methods for this vendor",
      );
      return DEV_PAYMENT_METHODS;
    }
    return methods;
  } catch (error) {
    if (useFawaterkDevFallback()) {
      const detail =
        error instanceof ApiError ? error.message : "Fawaterk unavailable";
      logFawaterkFallbackOnce(`Fawaterk error: ${detail}`);
      return DEV_PAYMENT_METHODS;
    }
    throw error;
  }
}

export async function getProjectPayment(projectId: number, userId: number) {
  const project = await db.project.findUnique({
    where: { id: projectId },
    include: { payment: true },
  });
  if (!project) throw new ApiError(404, "Project not found");

  const isClient = project.clientId === userId;
  const acceptedBid = await db.bid.findFirst({
    where: { projectId, status: "ACCEPTED" },
    include: { engineer: { include: { user: { select: { id: true } } } } },
  });
  const isEngineer = acceptedBid?.engineer.user.id === userId;

  if (!isClient && !isEngineer) {
    throw new ApiError(403, "You do not have access to this payment");
  }

  return project.payment;
}

export async function initiateProjectCheckout(
  clientId: number,
  projectId: number,
  input: InitiateCheckoutInput,
) {
  const project = await db.project.findUnique({
    where: { id: projectId },
    include: { payment: true, client: true },
  });
  if (!project) throw new ApiError(404, "Project not found");
  if (project.clientId !== clientId) {
    throw new ApiError(403, "Only the project owner can fund escrow");
  }
  if (project.status !== "IN_PROGRESS") {
    throw new ApiError(
      400,
      "Escrow payment is only available for in-progress projects",
    );
  }

  if (project.payment?.status === "FUNDED") {
    throw new ApiError(400, "Escrow is already funded for this project");
  }
  if (project.payment?.status === "RELEASED") {
    throw new ApiError(400, "Payment has already been released");
  }

  const bid = await getAcceptedBidForProject(projectId);
  // bid.engineerId is the EngineerProfile.id — correct foreign key for Payment.engineerId
  const engineerProfileId = bid.engineerId;
  const config = getFawaterkConfig();
  const amount = toNumber(bid.price);
  const commission = Math.round(amount * config.commissionRate * 100) / 100;
  // Client is charged amount + commission so the platform fee is actually collected
  const totalCharged = Math.round((amount + commission) * 100) / 100;
  const { first_name, last_name } = splitCustomerName(project.client.name);

  const payment =
    project.payment ??
    (await db.payment.create({
      data: {
        projectId,
        clientId,
        engineerId: engineerProfileId,
        amount,
        commission,
        status: "PENDING",
      },
    }));

  const redirectionUrls = getRedirectionUrls(projectId, payment.id);
  const fawaterkData = await initiateFawaterkPayment({
    payment_method_id: input.paymentMethodId,
    cartTotal: String(totalCharged),
    currency: config.currency,
    customer: {
      first_name,
      last_name,
      email: project.client.email,
      phone: input.phone ?? "01000000000",
      address: input.address ?? "N/A",
    },
    redirectionUrls,
    cartItems: [
      {
        name: project.title.slice(0, 100),
        price: String(totalCharged),
        quantity: "1",
      },
    ],
    payLoad: {
      projectId,
      paymentId: payment.id,
    },
  });

  const updatedPayment = await db.payment.update({
    where: { id: payment.id },
    data: {
      gatewayInvoiceId: String(fawaterkData.invoice_id),
      gatewayInvoiceKey: fawaterkData.invoice_key,
      status: "PENDING",
    },
  });

  return {
    payment: updatedPayment,
    invoiceId: fawaterkData.invoice_id,
    invoiceKey: fawaterkData.invoice_key,
    paymentData: fawaterkData.payment_data,
  };
}

/** Prepare Fawaterak IFrame checkout — creates pending payment + plugin config */
export async function prepareProjectCheckoutSession(
  clientId: number,
  projectId: number,
  phone?: string,
  address?: string,
) {
  const project = await db.project.findUnique({
    where: { id: projectId },
    include: { payment: true, client: true },
  });
  if (!project) throw new ApiError(404, "Project not found");
  if (project.clientId !== clientId) {
    throw new ApiError(403, "Only the project owner can fund escrow");
  }
  if (project.status !== "IN_PROGRESS") {
    throw new ApiError(
      400,
      "Escrow payment is only available for in-progress projects",
    );
  }
  if (project.payment?.status === "FUNDED") {
    throw new ApiError(400, "Escrow is already funded for this project");
  }
  if (project.payment?.status === "RELEASED") {
    throw new ApiError(400, "Payment has already been released");
  }

  const iframe = buildIframeHashKey();
  if (!iframe) {
    throw new ApiError(
      503,
      "Payment gateway is not configured (FAWATERK_VENDOR_KEY / FAWATERK_PROVIDER_KEY missing)",
    );
  }

  const bid = await getAcceptedBidForProject(projectId);
  // bid.engineerId is the EngineerProfile.id — correct foreign key for Payment.engineerId
  const engineerProfileId = bid.engineerId;
  const config = getFawaterkConfig();
  const amount = toNumber(bid.price);
  const commission = Math.round(amount * config.commissionRate * 100) / 100;
  // Client is charged amount + commission so the platform fee is actually collected
  const totalCharged = Math.round((amount + commission) * 100) / 100;
  const { first_name, last_name } = splitCustomerName(project.client.name);

  const payment =
    project.payment ??
    (await db.payment.create({
      data: {
        projectId,
        clientId,
        engineerId: engineerProfileId,
        amount,
        commission,
        status: "PENDING",
      },
    }));

  const redirectionUrls = getRedirectionUrls(projectId, payment.id);

  return {
    hashKey: iframe.hashKey,
    envType: iframe.envType,
    currency: config.currency,
    projectId,
    projectTitle: project.title,
    paymentId: payment.id,
    amount,
    commission,
    totalCharged,
    useDevFallback: useFawaterkDevFallback(),
    pluginRequest: {
      cartTotal: String(totalCharged),
      currency: config.currency,
      customer: {
        first_name,
        last_name,
        email: project.client.email,
        phone: phone ?? "01000000000",
        address: address ?? "N/A",
      },
      redirectionUrls: {
        successUrl: redirectionUrls.successUrl,
        failUrl: redirectionUrls.failUrl,
        pendingUrl: redirectionUrls.pendingUrl,
      },
      cartItems: [
        {
          name: project.title.slice(0, 100),
          price: String(totalCharged),
          quantity: "1",
        },
      ],
      payLoad: {
        projectId,
        paymentId: payment.id,
      },
    },
  };
}

export async function handleFawaterkWebhook(body: unknown) {
  const config = getFawaterkConfig();

  const paidParse = paidWebhookSchema.safeParse(body);
  if (paidParse.success && paidParse.data.invoice_status === "paid") {
    const payload = paidParse.data;

    const valid = verifyPaidWebhookHash(
      payload.invoice_id,
      payload.invoice_key,
      payload.payment_method,
      payload.hashKey,
      config.vendorKey,
    );
    if (!valid) {
      throw new ApiError(401, "Invalid webhook signature");
    }

    let payment = await db.payment.findFirst({
      where: {
        OR: [
          { gatewayInvoiceKey: payload.invoice_key },
          { gatewayInvoiceId: String(payload.invoice_id) },
        ],
      },
    });

    if (!payment) {
      const pl = parsePayLoad(payload.pay_load);
      if (pl?.paymentId) {
        payment = await db.payment.findUnique({ where: { id: pl.paymentId } });
      }
    }

    if (!payment) {
      throw new ApiError(404, "Payment record not found for this invoice");
    }

    const netAmount = netEngineerAmount(payment.amount, payment.commission);

    const updated = await db.$transaction(async (tx) => {
      const funded = await tx.payment.update({
        where: { id: payment!.id },
        data: {
          status: "FUNDED",
          gatewayInvoiceId: String(payload.invoice_id),
          gatewayInvoiceKey: payload.invoice_key,
        },
        include: {
          project: { select: { id: true, title: true, clientId: true, status: true } },
          engineer: { include: { user: { select: { id: true } } } },
        },
      });

      if (funded.project.status !== "IN_PROGRESS") {
        await tx.project.update({
          where: { id: funded.projectId },
          data: { status: "IN_PROGRESS" },
        });
      }

      await recordPaymentLedger(tx, funded.id, [
        {
          type: "FUNDED",
          amount: toNumber(funded.amount) + toNumber(funded.commission),
          note: "Client escrow payment received via Fawaterak",
        },
        {
          type: "ENGINEER_ESCROW",
          amount: netAmount,
          note: "Engineer share held in escrow",
        },
        {
          type: "PLATFORM_COMMISSION",
          amount: funded.commission,
          note: "Platform commission on funded payment",
        },
      ]);

      return funded;
    });

    const { createNotification } = await import("../../utils/notifications");
    await createNotification(
      updated.engineer.user.id,
      "ESCROW_FUNDED",
      "Payment received",
      `The client paid for "${updated.project.title}". You can start working.`,
      `/messages?project=${updated.projectId}`,
    );
    await createNotification(
      updated.engineer.user.id,
      "PROJECT_STARTED",
      "Project started",
      `Escrow is funded for "${updated.project.title}". Begin work when ready.`,
      `/messages?project=${updated.projectId}`,
    );
    await createNotification(
      updated.project.clientId,
      "PAYMENT_RECEIVED",
      "Payment successful",
      `Your payment for "${updated.project.title}" is secured in escrow.`,
      `/escrow?project=${updated.projectId}`,
    );

    return { handled: true, type: "paid", paymentId: payment.id };
  }

  const expiredParse = expiredWebhookSchema.safeParse(body);
  if (expiredParse.success && expiredParse.data.status === "EXPIRED") {
    const payload = expiredParse.data;

    const valid = verifyExpiredWebhookHash(
      payload.referenceId,
      payload.paymentMethod,
      payload.hashKey,
      config.vendorKey,
    );
    if (!valid) {
      throw new ApiError(401, "Invalid webhook signature");
    }

    if (payload.transactionKey) {
      const payment = await db.payment.findFirst({
        where: { gatewayInvoiceKey: payload.transactionKey },
      });
      if (payment && payment.status === "PENDING") {
        await db.payment.update({
          where: { id: payment.id },
          data: {
            gatewayInvoiceId: null,
            gatewayInvoiceKey: null,
          },
        });
      }
    }

    return { handled: true, type: "expired" };
  }

  return { handled: false };
}

export type EngineerPaymentDisplayStatus =
  | "awaiting_payment"
  | "in_progress"
  | "paid"
  | "refunded";

function mapEngineerPaymentStatus(
  paymentStatus: string,
  projectStatus: string,
): EngineerPaymentDisplayStatus {
  if (paymentStatus === "PENDING") return "awaiting_payment";
  if (paymentStatus === "REFUNDED") return "refunded";
  if (paymentStatus === "RELEASED") return "paid";
  if (paymentStatus === "FUNDED") return "in_progress";
  return "awaiting_payment";
}

export async function getEngineerBalance(engineerUserId: number) {
  const profile = await db.engineerProfile.findUnique({
    where: { userId: engineerUserId },
    select: { id: true },
  });
  if (!profile) {
    return {
      availableBalance: 0,
      pendingBalance: 0,
      securedBalance: 0,
      awaitingClientPayment: 0,
      transactions: [] as Array<{
        id: number;
        projectId: number;
        projectTitle: string;
        amount: number;
        netAmount: number;
        commission: number;
        status: EngineerPaymentDisplayStatus;
        createdAt: Date;
        updatedAt: Date;
      }>,
      walletHistory: [] as Array<{
        id: number;
        amount: number;
        type: "PROJECT_PAYMENT" | "RELEASED" | "WITHDRAWAL";
        status: "PENDING" | "AVAILABLE" | "COMPLETED" | "REJECTED";
        description: string | null;
        availableAt: Date | null;
        relatedPaymentId: number | null;
        relatedWithdrawalId: number | null;
        createdAt: Date;
      }>,
      withdrawalRequests: [] as Array<{
        id: number;
        amount: number;
        method: string;
        accountNumber: string;
        status: "PENDING" | "PROCESSING" | "COMPLETED" | "REJECTED";
        adminNotes: string | null;
        processedAt: Date | null;
        createdAt: Date;
      }>,
    };
  }

  const { wallet } = await db.$transaction(async (tx) =>
    settleMaturedWalletTransactions(tx, engineerUserId),
  );

  const payments = await db.payment.findMany({
    where: { engineerId: profile.id },
    include: {
      project: { select: { id: true, title: true, status: true } },
    },
    orderBy: { updatedAt: "desc" },
  });

  let availableBalance = 0;
  let securedBalance = 0;
  let awaitingClientPayment = 0;

  const transactions = payments.map((payment) => {
    const netAmount = netEngineerAmount(payment.amount, payment.commission);
    const status = mapEngineerPaymentStatus(
      payment.status,
      payment.project.status,
    );

    if (status === "paid") availableBalance += netAmount;
    else if (status === "in_progress") securedBalance += netAmount;
    else if (status === "awaiting_payment") {
      awaitingClientPayment += netAmount;
    }

    return {
      id: payment.id,
      projectId: payment.projectId,
      projectTitle: payment.project.title,
      amount: payment.amount,
      netAmount,
      commission: payment.commission,
      status,
      createdAt: payment.createdAt,
      updatedAt: payment.updatedAt,
    };
  });

  const [walletHistory, withdrawalRequests] = await Promise.all([
    db.walletTransaction.findMany({
      where: { walletId: wallet.id },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    db.withdrawalRequest.findMany({
      where: { userId: engineerUserId },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
  ]);

  return {
    availableBalance: wallet.availableBalance,
    pendingBalance: wallet.pendingBalance,
    securedBalance,
    awaitingClientPayment,
    transactions,
    walletHistory,
    withdrawalRequests,
  };
}

export async function listEngineerWithdrawalRequests(engineerUserId: number) {
  await db.$transaction(async (tx) =>
    settleMaturedWalletTransactions(tx, engineerUserId),
  );

  return db.withdrawalRequest.findMany({
    where: { userId: engineerUserId },
    orderBy: { createdAt: "desc" },
  });
}

export async function createEngineerWithdrawalRequest(
  engineerUserId: number,
  input: CreateWithdrawalRequestInput,
) {
  const engineer = await db.user.findUnique({
    where: { id: engineerUserId },
    select: { id: true, name: true, email: true, role: true },
  });
  if (!engineer || engineer.role !== "ENGINEER") {
    throw new ApiError(403, "Only engineers can request withdrawals");
  }

  const amount = Math.round(input.amount * 100) / 100;
  if (amount <= 0) {
    throw new ApiError(400, "Withdrawal amount must be greater than zero");
  }

  const request = await db.$transaction(async (tx) => {
    const { wallet } = await settleMaturedWalletTransactions(tx, engineerUserId);

    const pendingRequests = await tx.withdrawalRequest.aggregate({
      where: {
        userId: engineerUserId,
        status: { in: ["PENDING", "PROCESSING"] },
      },
      _sum: { amount: true },
    });

    const reserved = pendingRequests._sum.amount ?? 0;
    const spendable = wallet.availableBalance - reserved;
    if (amount > spendable) {
      throw new ApiError(
        400,
        `Withdrawal exceeds available spendable balance (${formatEgp(spendable)})`,
      );
    }

    const created = await tx.withdrawalRequest.create({
      data: {
        userId: engineerUserId,
        amount,
        method: input.method,
        accountNumber: input.accountNumber,
        status: "PENDING",
      },
    });

    await tx.walletTransaction.create({
      data: {
        walletId: wallet.id,
        amount,
        type: "WITHDRAWAL",
        status: "PENDING",
        description: `Withdrawal requested via ${input.method}`,
        relatedWithdrawalId: created.id,
      },
    });

    return created;
  });

  await sendWithdrawalRequestEmailToAdmins({
    engineerName: engineer.name,
    engineerEmail: engineer.email,
    amount,
    method: input.method,
    accountNumber: input.accountNumber,
    requestDate: request.createdAt,
  });

  return request;
}

export async function listEngineerEscrow(engineerUserId: number) {
  const balance = await getEngineerBalance(engineerUserId);
  return balance.transactions.map((tx) => ({
    id: tx.id,
    projectId: tx.projectId,
    projectTitle: tx.projectTitle,
    amount: tx.netAmount,
    commission: tx.commission,
    status: mapEngineerEscrowLegacyStatus(tx.status),
    createdAt: tx.createdAt,
    updatedAt: tx.updatedAt,
  }));
}

function mapEngineerEscrowLegacyStatus(
  status: EngineerPaymentDisplayStatus,
): "Pending" | "In escrow" | "Released" | "Refunded" {
  switch (status) {
    case "awaiting_payment":
      return "Pending";
    case "in_progress":
      return "In escrow";
    case "paid":
      return "Released";
    case "refunded":
      return "Refunded";
    default:
      return "Pending";
  }
}

export async function listClientEscrow(clientId: number) {
  const payments = await db.payment.findMany({
    where: { clientId },
    include: {
      project: { select: { id: true, title: true, status: true } },
    },
    orderBy: { updatedAt: "desc" },
  });

  return payments.map((payment) => ({
    id: payment.id,
    projectId: payment.projectId,
    projectTitle: payment.project.title,
    projectStatus: payment.project.status,
    amount: payment.amount,
    commission: payment.commission,
    status: mapPaymentStatusToEscrow(payment.status),
    createdAt: payment.createdAt,
    updatedAt: payment.updatedAt,
  }));
}

function mapPaymentStatusToEscrow(
  status: string,
): "Pending" | "In escrow" | "Released" | "Refunded" {
  switch (status) {
    case "PENDING":
      return "Pending";
    case "FUNDED":
      return "In escrow";
    case "RELEASED":
      return "Released";
    case "REFUNDED":
      return "Refunded";
    default:
      return "Pending";
  }
}

export async function releaseEscrowPayment(
  clientId: number,
  paymentId: number,
) {
  const payment = await db.payment.findUnique({
    where: { id: paymentId },
    include: { project: { select: { title: true, status: true } } },
  });
  if (!payment) throw new ApiError(404, "Payment not found");
  if (payment.clientId !== clientId) {
    throw new ApiError(403, "Only the client can release escrow funds");
  }
  if (payment.status !== "FUNDED") {
    throw new ApiError(400, "Escrow must be funded before release");
  }
  if (!isReviewableStatus(payment.project.status)) {
    throw new ApiError(
      400,
      "The engineer must submit work before you can release payment",
    );
  }

  const netAmount = netEngineerAmount(payment.amount, payment.commission);
  const projectTitle = payment.project?.title ?? "Project";
  const engineerProfile = await db.engineerProfile.findUnique({
    where: { id: payment.engineerId },
    select: { userId: true },
  });
  if (!engineerProfile) {
    throw new ApiError(404, "Engineer profile not found for this payment");
  }

  const updated = await db.$transaction(async (tx) => {
    const released = await tx.payment.update({
      where: { id: paymentId },
      data: { status: "RELEASED" },
    });
    await tx.project.update({
      where: { id: payment.projectId },
      data: { status: "COMPLETED" },
    });
    await recordPaymentLedger(tx, paymentId, [
      {
        type: "RELEASED",
        amount: netAmount,
        note: "Escrow released to engineer after client approval",
      },
      {
        type: "PLATFORM_COMMISSION",
        amount: payment.commission,
        note: "Platform commission retained on release",
      },
    ]);

    const wallet = await ensureWallet(tx, engineerProfile.userId);
    await tx.wallet.update({
      where: { id: wallet.id },
      data: {
        pendingBalance: { increment: netAmount },
      },
    });
    await tx.walletTransaction.create({
      data: {
        walletId: wallet.id,
        amount: netAmount,
        type: "RELEASED",
        status: "PENDING",
        description: `Payment released for \"${projectTitle}\". Available after 14-day hold.`,
        availableAt: walletHoldReleaseDate(),
        relatedPaymentId: paymentId,
      },
    });

    return released;
  });

  const { createNotification } = await import("../../utils/notifications");
  await createNotification(
    engineerProfile.userId,
    "WORK_APPROVED",
    "Work approved",
    `The client approved your work on "${projectTitle}". Earnings are now pending in your wallet.`,
    `/balance`,
  );
  await createNotification(
    engineerProfile.userId,
    "FUNDS_RELEASED",
    "Payment queued to wallet",
    `The client released payment for "${projectTitle}". Funds will become available after the 14-day holding period.`,
    `/balance`,
  );
  await createNotification(
    payment.clientId,
    "PROJECT_COMPLETED",
    "Project completed",
    `Payment for "${projectTitle}" has been released. You can leave a review.`,
    `/projects?id=${payment.projectId}`,
  );

  return updated;
}

export async function getEscrowPaymentById(paymentId: number, userId: number) {
  const payment = await db.payment.findUnique({
    where: { id: paymentId },
    include: {
      project: {
        select: { id: true, title: true, status: true, clientId: true },
      },
    },
  });
  if (!payment) throw new ApiError(404, "Payment not found");

  const isClient = payment.clientId === userId;
  const acceptedBid = await db.bid.findFirst({
    where: { projectId: payment.projectId, status: "ACCEPTED" },
    include: { engineer: { include: { user: { select: { id: true } } } } },
  });
  const isEngineer = acceptedBid?.engineer.user.id === userId;

  if (!isClient && !isEngineer) {
    throw new ApiError(403, "You do not have access to this payment");
  }

  return {
    id: payment.id,
    projectId: payment.projectId,
    projectTitle: payment.project.title,
    amount: payment.amount,
    commission: payment.commission,
    status: mapPaymentStatusToEscrow(payment.status),
    gatewayInvoiceId: payment.gatewayInvoiceId,
    gatewayInvoiceKey: payment.gatewayInvoiceKey,
    createdAt: payment.createdAt,
    updatedAt: payment.updatedAt,
  };
}

export async function verifyOrSimulatePaymentSuccess(
  clientId: number,
  paymentId: number,
) {
  const payment = await db.payment.findUnique({
    where: { id: paymentId },
    include: {
      project: { select: { id: true, title: true, status: true } },
      engineer: { include: { user: { select: { id: true } } } },
    },
  });
  if (!payment) throw new ApiError(404, "Payment not found");
  if (payment.clientId !== clientId) {
    throw new ApiError(403, "Only the client can verify this payment");
  }

  if (payment.status === "FUNDED" || payment.status === "RELEASED") {
    return payment;
  }
  if (payment.status === "REFUNDED") {
    throw new ApiError(400, "Cannot verify a refunded payment");
  }

  const netAmount = netEngineerAmount(payment.amount, payment.commission);

  const updated = await db.$transaction(async (tx) => {
    const funded = await tx.payment.update({
      where: { id: payment.id },
      data: { status: "FUNDED" },
      include: {
        project: { select: { id: true, title: true, clientId: true, status: true } },
        engineer: { include: { user: { select: { id: true } } } },
      },
    });

    await recordPaymentLedger(tx, funded.id, [
      {
        type: "FUNDED",
        amount: toNumber(funded.amount) + toNumber(funded.commission),
        note: "Client escrow payment manually verified",
      },
      {
        type: "ENGINEER_ESCROW",
        amount: netAmount,
        note: "Engineer share held in escrow",
      },
      {
        type: "PLATFORM_COMMISSION",
        amount: funded.commission,
        note: "Platform commission on funded payment",
      },
    ]);

    return funded;
  });

  const { createNotification } = await import("../../utils/notifications");
  await createNotification(
    updated.engineer.user.id,
    "ESCROW_FUNDED",
    "Payment received",
    `The client paid for "${updated.project.title}". You can start working.`,
    `/messages?project=${updated.projectId}`,
  );

  await createNotification(
    updated.project.clientId,
    "PAYMENT_RECEIVED",
    "Payment successful",
    `Your payment for "${updated.project.title}" is secured in escrow.`,
    `/escrow?project=${updated.projectId}`,
  );

  return updated;
}

export async function refundEscrowPayment(clientId: number, paymentId: number) {
  const payment = await db.payment.findUnique({
    where: { id: paymentId },
    include: { project: { select: { title: true } } },
  });
  if (!payment) throw new ApiError(404, "Payment not found");
  if (payment.clientId !== clientId) {
    throw new ApiError(403, "Only the client can request a refund");
  }
  if (payment.status !== "FUNDED") {
    throw new ApiError(400, "Only funded escrow can be refunded");
  }

  // Cancel the project and mark payment refunded atomically
  const updated = await db.$transaction(async (tx) => {
    const refunded = await tx.payment.update({
      where: { id: paymentId },
      data: { status: "REFUNDED" },
    });
    await tx.project.update({
      where: { id: payment.projectId },
      data: { status: "CANCELLED" },
    });
    return refunded;
  });

  // Notify the engineer so they're not left wondering
  const engineerProfile = await db.engineerProfile.findUnique({
    where: { id: payment.engineerId },
    select: { userId: true },
  });
  const { createNotification } = await import("../../utils/notifications");
  if (engineerProfile) {
    await createNotification(
      engineerProfile.userId,
      "ESCROW_REFUNDED",
      "Payment refunded",
      `The client was refunded for "${payment.project.title}". The project has been cancelled.`,
      `/balance`,
    );
  }

  return updated;
}
